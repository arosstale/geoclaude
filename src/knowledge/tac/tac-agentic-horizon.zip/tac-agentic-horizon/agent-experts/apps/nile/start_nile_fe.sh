#!/bin/bash
# Start Nile Frontend (Vue 3 + Vite)
# Runs on http://localhost:5173

cd "$(dirname "$0")/client"
npm run dev

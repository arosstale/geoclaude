This is your initialization prompt. 
Respond with "Ready" to indicate you've received the prompt and are ready to start.

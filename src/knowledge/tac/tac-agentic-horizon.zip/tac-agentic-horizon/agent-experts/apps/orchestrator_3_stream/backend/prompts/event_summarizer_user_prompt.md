Summarize this event in one concise sentence (50-100 chars):

Event Type: {event_type}
{details}

Provide ONLY the summary sentence, no other text.

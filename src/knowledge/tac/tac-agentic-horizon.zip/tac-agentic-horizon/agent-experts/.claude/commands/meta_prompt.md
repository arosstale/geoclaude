---
allowed-tools: Write, Edit, WebFetch, Task, mcp__firecrawl-mcp__firecrawl_scrape, Fetch
description: Create a new prompt based on a user's request
---

# Purpose

This meta prompt takes the `USER_PROMPT_REQUEST` and follows the `Workflow` to create a new prompt in the `Specified Format`.

## Variables

USER_PROMPT_REQUEST: $ARGUMENTS
PROMPT_OUTPUT_PATH: `.claude/commands/<name_of_prompt_based_on_user_prompt_request>.md`

## Instructions

- We're building a new prompt to satisfy the request detailed in the `USER_PROMPT_REQUEST`.
- Save the new prompt to `PROMPT_OUTPUT_PATH`
  - The name of the prompt should make sense based on the `USER_PROMPT_REQUEST`
- VERY IMPORTANT: The prompt should be in the `Specified Format`
  - Do not create any additional sections or headers that are not in the `Specified Format`
- IMPORTANT: As you're working through the `Specified Format`, replace every block of `<some request>` with the request detailed within the braces.
- Note we're calling these 'prompts' they're also known as custom slash commands.
- Use one Task tool per documentation item to run sub tasks to gather documentation quickly in parallel using `Task` and `WebFetch`.
- Ultra Think - you're operating a prompt that builds a prompt. Stay focused on the details of creating the best high quality prompt for other ai agents.
- Note, if no variables are requested or mentioned, do not create a Variables section.
- Think through what the static variables vs dynamic variables are and place them accordingly with dynamic variables coming first and static variables coming second.
  - Prefer the `$1`, `$2`, ... over the `$ARGUMENTS` notation.

## Workflow

- Read the documentation
    - Slash Command Documentation: https://code.claude.com/docs/en/slash-commands
    - Create Custom Slash Commands: https://code.claude.com/docs/en/common-workflows#create-custom-slash-commands
    - Available Tools and Settings: https://code.claude.com/docs/en/settings
- Understand the `USER_PROMPT_REQUEST`.
- Create the new prompt in the `Specified Format` that satisfies the `USER_PROMPT_REQUEST` and save it to `PROMPT_OUTPUT_PATH`

## Specified Format
```md
---
allowed-tools: <allowed-tools comma separated>
description: <description we'll use to id this prompt>
argument-hint: [<argument-hint for the first dynamic variable>], [<argument-hint for the second dynamic variable>]
model: <requested model or default to 'opus' if not specified>
---

# Purpose

<prompt purpose: here we describe what the prompt does at a high level and reference any sections we create that are relevant like the `Instructions` section. Every prompt must have an `Instructions` section where we detail the instructions for the prompt in a bullet point list>

## Variables

<exclude this section if no variables are requested or mentioned>

<NAME_OF_DYNAMIC_VARIABLE>: $1
<NAME_OF_DYNAMIC_VARIABLE>: $2
<NAME_OF_STATIC_VARIABLE>: <SOMETHING STATIC>

## Instructions
<detailed bullet point list of instructions for the prompt. These bullet points aid the workflow but are not part of the workflow itself.>

## Workflow
<step by step numbered list of tasks to complete to accomplish the prompt>

## Report
<details of how the prompt should respond back to the user based on the prompt>

```
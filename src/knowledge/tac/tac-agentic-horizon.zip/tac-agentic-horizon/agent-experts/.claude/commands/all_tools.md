# List All Tools

List all available tools detailed in your system prompt. Display them in bullet points. Display them in typescript function signature format and suffix the purpose of the tool. Double line break between each tool for readability.
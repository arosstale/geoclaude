# Health Check

!`uv run adws/adw_tests/health_check.py`

Report the results of the health check.
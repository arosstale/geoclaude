# Install & Prime

## Read and Execute
.claude/commands/prime.md

## Run
Install FE and BE dependencies
Run `./scripts/copy_dot_env.sh` to copy the .env file from the tac-2 directory.

## Report
Output the work you've just done in a concise bullet point list.
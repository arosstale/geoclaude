# Prime
> Execute the following sections to understand the codebase then summarize your understanding.

## Run
git ls-files

## Read
README.md
adws/README.md
.claude/commands/conditional_docs.md - this is a guide for you to determine which documentation to read based on the upcoming task.
# Prime
> Execute the following sections to understand the codebase then summarize your understanding.

## Run
git ls-files

## Read
README.md
adws/README.md
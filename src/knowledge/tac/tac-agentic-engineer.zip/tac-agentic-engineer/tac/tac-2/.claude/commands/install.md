# Install & Prime

## Read and Execute
.claude/commands/prime.md

## Run
Install FE and BE dependencies
